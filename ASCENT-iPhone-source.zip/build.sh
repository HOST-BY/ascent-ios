#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "IPA requires macOS and Xcode. Use the included GitHub Actions workflow."
  exit 1
fi
sdk=$(xcrun --sdk iphoneos --show-sdk-path)
build_dir=$(mktemp -d "$PWD/build-ios.XXXXXX")
output="$PWD/dist/ASCENT-iPhone-unsigned.ipa"
app="$build_dir/Payload/ASCENT.app"
mkdir -p "$app" "$app/Frameworks" dist
xcrun swiftc -swift-version 5 -parse-as-library -O -sdk "$sdk" \
  -target arm64-apple-ios16.0 -module-name ASCENT \
  -framework UIKit -framework WebKit -framework UniformTypeIdentifiers -framework Security \
  -Xlinker -rpath -Xlinker '@executable_path/Frameworks' \
  Native/AscentStore.swift Native/App.swift -o "$app/ASCENT"
cp Info.plist "$app/Info.plist"
cp -R Web "$app/Web"
sips -z 120 120 Web/ascent.png --out "$app/AppIcon60@2x.png" >/dev/null
sips -z 180 180 Web/ascent.png --out "$app/AppIcon60@3x.png" >/dev/null
xcrun swift-stdlib-tool --copy --scan-executable "$app/ASCENT" --platform iphoneos --destination "$app/Frameworks"
plutil -lint "$app/Info.plist"
python3 - "$app" <<'PY'
import pathlib, sys, plistlib, subprocess
app = pathlib.Path(sys.argv[1])
info = plistlib.loads((app/'Info.plist').read_bytes())
info['CFBundleSupportedPlatforms'] = ['iPhoneOS']
info['DTPlatformName'] = 'iphoneos'
info['DTSDKName'] = 'iphoneos' + subprocess.check_output(['xcrun','--sdk','iphoneos','--show-sdk-version'],text=True).strip()
(app/'Info.plist').write_bytes(plistlib.dumps(info))
assert (app/'ASCENT').stat().st_size > 0
assert (app/'Web/index.html').exists()
PY
# AltStore signs this device build with the user's own Apple ID during installation.
if [[ -f "$output" ]]; then rm "$output"; fi
(cd "$build_dir" && /usr/bin/zip -qr "$output" Payload)
echo "Created: dist/ASCENT-iPhone-unsigned.ipa (sign/install with AltStore Classic)"
