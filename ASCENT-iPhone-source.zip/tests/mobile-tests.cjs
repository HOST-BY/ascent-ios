const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs');
module.exports=async function(browser){
 fs.mkdirSync(path.resolve(__dirname,'../test-output'),{recursive:true});
 const ctx=await browser.newContext({viewport:{width:430,height:932},isMobile:true,hasTouch:true,deviceScaleFactor:1}),p=await ctx.newPage(),errors=[];
 p.on('pageerror',e=>errors.push(e.message));
 await ctx.addInitScript(()=>{
  window.__nativeCalls=[];window.__export=null;window.__import=null;
  window.webkit={messageHandlers:{ascent:{postMessage:async({method,payload})=>{
   window.__nativeCalls.push(method);
   if(method==='load')return {json:localStorage.getItem('native-test-data'),recovered:false};
   if(method==='save'){localStorage.setItem('native-test-data',payload.json);return true;}
   if(method==='info')return {version:'ios-test',dataDir:'Тестовое хранилище iPhone',keyConfigured:false};
   if(method==='export'){window.__export=payload.json;return true;}
   if(method==='import')return window.__import;
   if(method==='notify')return true;
   throw new Error('Unsupported mock method '+method);
  }}}};
 });
 await p.goto('file:///'+path.resolve(__dirname,'../Web/index.html').replaceAll('\\','/'));await p.waitForFunction(()=>AscentApp.ready);
 const go=async name=>{await p.locator('#mobile-menu summary').click();await p.locator('.life-nav [data-page='+name+']').click();assert.equal(await p.locator('#mobile-menu').getAttribute('open'),null);};
 const flush=()=>p.waitForFunction(()=>AscentApp.canClose()),state=()=>p.evaluate(()=>AscentApp.getState()),save=async()=>{await p.locator('#modal [type=submit]').click();await p.waitForFunction(()=>!document.getElementById('modal').open);await flush();};
 for(const section of ['day','habits','creative','finance','body','notes','ai','settings','goals']){await go(section);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2),false,'Overflow '+section);}
 await go('day');await p.locator('#content [data-action=new-task]').click();await p.locator('#modal [name=title]').fill('План на iPhone');await p.locator('#modal [name=description]').fill('Записать идею\nСделать маленький шаг');await save();const task=(await state()).tasks[0];assert.equal(task.title,'План на iPhone');
 await p.locator('[data-priority-task]').selectOption('high');await flush();await p.locator('[data-action=toggle-description]').click();await flush();assert.equal(await p.locator('.app-task-description').isVisible(),false);await p.locator('[data-action=show-descriptions]').click();await flush();
 await p.screenshot({path:path.resolve(__dirname,'../test-output/screenshot-iphone-day.png'),fullPage:true});
 await go('settings');await p.locator('[data-action=export-backup]').click();const exported=await p.evaluate(()=>window.__export);assert.ok(exported);const old=JSON.parse(exported);old.tasks[0].title='Перенос с ПК';await p.evaluate(json=>window.__import=json,JSON.stringify(old));await p.locator('[data-action=import-backup]').click();assert.ok(await p.locator('#modal').isVisible());assert.equal((await state()).tasks[0].title,'План на iPhone');await p.locator('[data-action=confirm-restore]').click();await flush();assert.equal((await state()).tasks[0].title,'Перенос с ПК');
 await p.reload();await p.waitForFunction(()=>AscentApp.ready);assert.equal((await state()).tasks[0].title,'Перенос с ПК');assert.equal(await p.evaluate(()=>localStorage.getItem('ascent-preview')),null,'iOS must use native bridge');
 await go('creative');await p.locator('#content [data-action=new-creative-idea]').first().click();await p.locator('#modal [name=title]').fill('Музыкальный набросок');await p.locator('#modal [name=text]').fill('Идея для нового трека');await save();assert.equal((await state()).creativeIdeas.length,1);
 await go('habits');await p.locator('[data-habit]').first().check();await flush();assert.equal((await state()).habits[0].dates.length,1);
 for(const width of [375,430,932]){await p.setViewportSize({width,height:width===932?430:932});for(const section of ['goals','day','habits','creative','settings']){await go(section);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2),false,section+' overflow at '+width);}}
 assert.deepEqual(errors,[]);await ctx.close();return 'PASS mobile UI 375/430/932 widths, navigation, tasks, priorities, descriptions, habits, creativity, native bridge mock, export/import confirmation and reload. Native iOS runtime not tested.';
};
