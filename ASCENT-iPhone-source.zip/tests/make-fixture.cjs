const fs=require('fs'),M=require('../Web/model.js');
fs.mkdirSync('test-output',{recursive:true});
fs.writeFileSync('test-output/fixture.json',JSON.stringify(M.initial()));
