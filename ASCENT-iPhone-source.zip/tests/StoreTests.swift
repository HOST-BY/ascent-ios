import Foundation

@main
struct StoreTests {
    static func main() throws {
        let source = URL(fileURLWithPath: CommandLine.arguments[1])
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("ascent-test-" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = try AscentStore(directory: directory)
        let initial = String(decoding: try Data(contentsOf: source), as: UTF8.self)
        try store.save(initial)
        var d = try JSONSerialization.jsonObject(with: Data(initial.utf8)) as! [String: Any]
        d["testValue"] = "Русский текст · 300 000 ₽"
        let updated = String(decoding: try JSONSerialization.data(withJSONObject: d), as: UTF8.self)
        try store.save(updated)
        precondition(tryString(store.dataURL) == updated)
        precondition(tryString(store.previousURL) == initial)
        var rejected = false
        do { try store.save("{}") } catch { rejected = true }
        precondition(rejected && tryString(store.dataURL) == updated)
        try Data("{broken".utf8).write(to: store.dataURL)
        let restored = try store.load()
        precondition(restored["recovered"] as? Bool == true)
        precondition(restored["json"] as? String == initial)
        let backups = try FileManager.default.contentsOfDirectory(atPath: directory.appendingPathComponent("backups").path)
        precondition(backups.count == 1)
        print("PASS native atomic save, UTF-8, backups, invalid-save rejection and recovery")
    }
    static func tryString(_ url: URL) -> String { (try? String(contentsOf: url, encoding: .utf8)) ?? "" }
}
