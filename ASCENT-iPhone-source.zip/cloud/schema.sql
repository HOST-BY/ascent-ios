-- ASCENT: private snapshots with optimistic concurrency. No admin key in clients.
begin;
create table if not exists public.ascent_documents (
  user_id uuid primary key references auth.users(id) on delete cascade,
  revision bigint not null default 1,
  document jsonb not null,
  updated_at timestamptz not null default now(),
  check (octet_length(document::text) <= 52428800),
  check (document->>'app' = 'ASCENT' and document->>'version' = '1')
);
alter table public.ascent_documents enable row level security;
revoke all on public.ascent_documents from anon, authenticated;
grant select on public.ascent_documents to authenticated;
create policy "Read own ASCENT" on public.ascent_documents for select to authenticated
  using ((select auth.uid()) = user_id);

create or replace function public.ascent_save(expected_revision bigint, new_document jsonb)
returns bigint language plpgsql security definer set search_path = '' as $$
declare owner_id uuid := auth.uid(); next_revision bigint;
begin
  if owner_id is null then raise exception 'Authentication required' using errcode = '42501'; end if;
  if expected_revision = 0 then
    insert into public.ascent_documents(user_id, document)
      values(owner_id, new_document) on conflict do nothing returning revision into next_revision;
  else
    update public.ascent_documents set document = new_document, revision = revision + 1, updated_at = now()
      where user_id = owner_id and revision = expected_revision returning revision into next_revision;
  end if;
  if next_revision is null then raise exception 'ASCENT_CONFLICT' using errcode = '40001'; end if;
  return next_revision;
end $$;
revoke all on function public.ascent_save(bigint,jsonb) from public, anon;
grant execute on function public.ascent_save(bigint,jsonb) to authenticated;
commit;
