window.AscentCryptoUI=function(o){
  'use strict';
  const C=AscentCrypto,{esc,btn,field,textarea,select,head,empty,formModal,commit,closeModal,toast,rpc}=o;
  let tab='portfolio',currency='USD',quotes={},quoteTime=0,quoteError='',quoteBusy=false,news=[],newsTime=0,newsError='',newsBusy=false,lastQuoteAttempt=0,lastNewsAttempt=0;
  try{const cache=JSON.parse(localStorage.getItem('ascent-crypto-market')||'{}');quotes=cache.quotes||{};quoteTime=cache.time||0;}catch{}
  const state=()=>o.get(),amount=(n,c=currency)=>n===null||!Number.isFinite(n)?'Нет данных':new Intl.NumberFormat('ru-RU',{style:'currency',currency:c,maximumFractionDigits:Math.abs(n)<1?6:2}).format(n);
  const qty=n=>new Intl.NumberFormat('ru-RU',{maximumFractionDigits:12}).format(n),pct=n=>n===null||!Number.isFinite(n)?'—':(n>=0?'+':'')+n.toFixed(2)+'%',tone=n=>n===null?'':n>=0?'crypto-positive':'crypto-negative';
  const time=n=>new Date(n).toLocaleString('ru-RU'),symbol=id=>C.coins[id].split(' · ')[0];
  const refreshUI=()=>{if(o.active()&&!document.getElementById('modal').open&&!document.activeElement?.matches('input,textarea,select'))o.render();};
  const fresh=id=>typeof quotes[id]?.last_updated_at==='number'&&Date.now()-quotes[id].last_updated_at*1000<15*60*1000;
  const quoteText=id=>amount(quotes[id]?.[currency.toLowerCase()]??null);
  const link=(url,label)=>'<a class="life-button" href="'+esc(url)+'" data-external>'+esc(label)+'</a>';
  async function prices(force=false){
    if(quoteBusy||Date.now()-lastQuoteAttempt<15000||!force&&(Date.now()-quoteTime<300000||Date.now()-lastQuoteAttempt<60000))return;
    lastQuoteAttempt=Date.now();
    quoteBusy=true;quoteError='';refreshUI();
    try{const data=JSON.parse(await rpc('cryptoPublic',{kind:'prices'}));const checked={};
      for(const id of Object.keys(C.coins)){const q=data[id];if(!q||!['usd','rub'].every(k=>typeof q[k]==='number'&&Number.isFinite(q[k])&&q[k]>0))continue;checked[id]=q;}
      if(!Object.keys(checked).length)throw Error('Источник не вернул котировки.');quotes=checked;quoteTime=Date.now();
      try{localStorage.setItem('ascent-crypto-market',JSON.stringify({quotes,time:quoteTime}));}catch{}
    }catch(e){quoteError='Не удалось обновить курсы: '+e.message;}finally{quoteBusy=false;refreshUI();}
  }
  async function loadNews(force=false){
    if(newsBusy||Date.now()-lastNewsAttempt<15000||!force&&(Date.now()-newsTime<900000||Date.now()-lastNewsAttempt<60000))return;lastNewsAttempt=Date.now();newsBusy=true;newsError='';refreshUI();
    try{const xml=await rpc('cryptoPublic',{kind:'news'}),doc=new DOMParser().parseFromString(xml,'text/xml');if(doc.querySelector('parsererror'))throw Error('Неверный формат ленты.');
      news=[...doc.querySelectorAll('item')].slice(0,30).map(item=>({title:item.querySelector('title')?.textContent||'',url:item.querySelector('link')?.textContent||'',date:Date.parse(item.querySelector('pubDate')?.textContent||'')})).filter(n=>n.title&&Number.isFinite(n.date)&&/^https:\/\/(www\.)?coindesk\.com\//.test(n.url));
      if(!news.length)throw Error('В ленте нет доступных новостей.');newsTime=Date.now();
    }catch(e){newsError='Новости не обновлены: '+e.message;}finally{newsBusy=false;refreshUI();}
  }
  function operationForm(id=''){
    const r=state().cryptoOperations.find(x=>x.id===id)||{coin:'bitcoin',type:'buy',quantity:'',price:'',currency,fx:'',fee:0,feeCurrency:'fiat',date:new Date().toISOString(),note:''};
    const d=new Date(r.date),localDate=new Date(d-d.getTimezoneOffset()*60000).toISOString().slice(0,16);
    formModal(id?'Изменить операцию':'Новая криптооперация','cryptoOperation',id,
      select('Монета','coin',r.coin,C.coins)+select('Операция','type',r.type,C.types)+field('Количество монет · до комиссии','quantity',r.quantity,'text','required inputmode="decimal"')+field('Цена за 1 монету','price',r.price??'','text','inputmode="decimal"')+select('Валюта цены и денежной комиссии','currency',r.currency,{USD:'Доллары · USD',RUB:'Рубли · RUB'})+field('Курс ₽ за $ на дату операции · необязательно','fx',r.fx??'','text','inputmode="decimal"')+field('Комиссия','fee',r.fee,'text','required inputmode="decimal"')+select('В чём комиссия','feeCurrency',r.feeCurrency,{fiat:'В валюте цены',coin:'В этой монете'})+field('Дата и время · местное время','date',localDate,'datetime-local','required',true)+textarea('Комментарий / кошелёк','note',r.note,'maxlength="2000"')+'<p class="life-small life-muted full">У начального остатка можно оставить цену пустой — прибыль будет неизвестна. Для покупки/продажи цена обязательна. Перевод между своими кошельками уменьшает общий баланс только на комиссию. Без исторического курса ₽/$ прибыль доступна только в валюте операции. В один момент времени покупки учитываются перед продажами.</p>',{deleteType:'cryptoOperation'});
  }
  function watchForm(id='',coin='bitcoin'){
    const r=state().cryptoWatch.find(x=>x.id===id)||{coin,target:null,currency,note:''};
    formModal(id?'Избранная монета':'Добавить в избранное','cryptoWatch',id,select('Монета','coin',r.coin,C.coins)+field('Желаемая цена входа · необязательно','target',r.target??'','text','inputmode="decimal"')+select('Валюта цели','currency',r.currency,{USD:'USD',RUB:'RUB'})+textarea('Почему наблюдаю','note',r.note,'maxlength="2000"'),{deleteType:'cryptoWatch'});
  }
  function ideaForm(id=''){
    const r=state().cryptoIdeas.find(x=>x.id===id)||{coin:'bitcoin',title:'',thesis:'',risks:'',exit:'',url:'',stage:'research'};
    formModal(id?'Изменить идею':'Идея сделки','cryptoIdea',id,field('Название','title',r.title,'text','required maxlength="180"',true)+select('Монета','coin',r.coin,C.coins)+select('Этап','stage',r.stage,{research:'Изучаю',watch:'Наблюдаю',closed:'Закрыта'})+textarea('Почему может быть интересна / план входа','thesis',r.thesis,'maxlength="5000"')+textarea('Риски / допустимый убыток','risks',r.risks,'maxlength="5000"')+textarea('Цель и условия выхода','exit',r.exit,'maxlength="2000"')+field('Источник · необязательно','url',r.url,'url','maxlength="2000"',true),{deleteType:'cryptoIdea'});
  }
  function taskForm(){formModal('Криптозадача','cryptoTask','',field('Что сделать','title','','text','required maxlength="400"',true)+select('Монета','coin','bitcoin',C.coins)+field('Дата','date',AscentModel.day(),'date','required')+textarea('Описание','description','','maxlength="20000"'));}
  async function submit(type,id,f){
    if(!type.startsWith('crypto'))return false;const v=k=>String(f.get(k)||'').trim();let collection,r;
    if(type==='cryptoOperation'){
      collection='cryptoOperations';const date=new Date(v('date'));if(!Number.isFinite(date.getTime())||date.getTime()>Date.now()+60000)throw Error('Укажи дату уже совершённой операции.');
      r={id:id||AscentModel.id(),coin:v('coin'),type:v('type'),quantity:C.parse(v('quantity')),price:C.parse(v('price'),true),currency:v('currency'),fx:C.parse(v('fx'),true),fee:C.parse(v('fee')),feeCurrency:v('feeCurrency'),date:date.toISOString(),note:v('note')};
    }
    if(type==='cryptoWatch'){collection='cryptoWatch';r={id:id||AscentModel.id(),coin:v('coin'),target:C.parse(v('target'),true),currency:v('currency'),note:v('note')};}
    if(type==='cryptoIdea'){collection='cryptoIdeas';r={id:id||AscentModel.id(),coin:v('coin'),title:v('title'),thesis:v('thesis'),risks:v('risks'),exit:v('exit'),url:v('url'),stage:v('stage')};}
    if(type==='cryptoTask'){await commit(()=>state().tasks.push(AscentModel.makeTask(v('title'),v('date'),{description:v('description'),cryptoCoin:v('coin')})));closeModal();toast('Задача добавлена в «Мой день».');return true;}
    await commit(()=>{const index=state()[collection].findIndex(x=>x.id===id);if(index<0)state()[collection].push(r);else state()[collection][index]=r;});closeModal();toast('Сохранено.');return true;
  }
  function portfolio(){
    const p=C.portfolio(state().cryptoOperations,quotes),t=p.total[currency],other=p.total[currency==='USD'?'RUB':'USD'];
    const metric=(label,value,sub,cls='')=>'<div class="crypto-metric life-surface"><span class="life-small life-muted">'+label+'</span><strong class="'+cls+'">'+value+'</strong><span class="life-small life-muted">'+sub+'</span></div>';
    const cards='<div class="crypto-metrics">'+metric('Стоимость портфеля',amount(t.value),amount(other.value,currency==='USD'?'RUB':'USD'))+metric('Вложено в оставшиеся монеты',amount(t.cost),'Средняя стоимость с комиссиями')+metric('Прибыль / убыток в портфеле',amount(t.unrealized),t.unrealized===null||!t.cost?'Процент недоступен':pct(t.unrealized/t.cost*100),tone(t.unrealized))+metric('Результат закрытых операций',amount(t.realized),'Продажи и расходы на переводы',tone(t.realized))+'</div>';
    if(!p.assets.length)return cards+empty('bitcoin','Добавь первую операцию','Запиши покупку или начальный остаток — здесь появятся стоимость и прибыль.',btn('Добавить операцию','crypto-operation','',true));
    return (p.assets.some(a=>a.quantity>0&&!fresh(a.coin))?'<p class="app-error">Есть устаревшие или отсутствующие котировки. Оценка портфеля может отличаться от текущей стоимости.</p>':'')+cards+'<div class="crypto-table-wrap life-surface"><table class="crypto-table"><thead><tr><th>Монета</th><th>Количество</th><th>Средняя покупка</th><th>Курс сейчас</th><th>Стоимость</th><th>Прибыль / убыток</th></tr></thead><tbody>'+p.assets.filter(a=>a.quantity>0).map(a=>{const v=a.values[currency];return '<tr><td><strong>'+esc(symbol(a.coin))+'</strong><div class="life-small life-muted">'+esc(C.coins[a.coin].split(' · ')[1])+'</div></td><td>'+qty(a.quantity)+'</td><td>'+amount(v.average)+'</td><td>'+amount(v.price)+'<div class="life-small life-muted">'+(fresh(a.coin)?'Обновлено '+time(quotes[a.coin].last_updated_at*1000):'Нет свежей котировки')+'</div></td><td>'+amount(v.value)+'</td><td class="'+tone(v.pnl)+'">'+amount(v.pnl)+'<div>'+pct(v.percent)+'</div></td></tr>';}).join('')+'</tbody></table></div><p class="life-small life-muted">Нет данных — отсутствует котировка, цена приобретения или исторический курс ₽/$. Проценты относятся к себестоимости оставшихся монет. Расчёт не является налоговым отчётом.</p>';
  }
  function operations(){
    const rows=[...state().cryptoOperations].sort((a,b)=>b.date.localeCompare(a.date));
    if(!rows.length)return empty('list','Операций пока нет','Покупки, продажи и начальные остатки добавляются вручную.',btn('Новая операция','crypto-operation'));
    return '<div class="crypto-list">'+rows.map(r=>'<article class="life-surface crypto-card"><div class="life-row-between"><h3>'+esc(C.types[r.type])+' · '+esc(symbol(r.coin))+'</h3>'+btn('Изменить','crypto-operation',r.id)+'</div><p>'+qty(r.quantity)+' '+esc(symbol(r.coin))+' · '+(r.price===null?'Цена неизвестна':amount(r.price,r.currency)+' за монету')+'</p><p class="life-small life-muted">'+time(Date.parse(r.date))+' · комиссия '+(r.feeCurrency==='coin'?qty(r.fee)+' '+symbol(r.coin):amount(r.fee,r.currency))+'</p>'+(r.note?'<p class="crypto-text">'+esc(r.note)+'</p>':'')+'</article>').join('')+'</div>';
  }
  function watch(){return '<div class="life-actions">'+btn('Добавить монету','crypto-watch')+'</div>'+(state().cryptoWatch.length?'<div class="crypto-list">'+state().cryptoWatch.map(w=>{const current=quotes[w.coin]?.[w.currency.toLowerCase()],hit=w.target&&typeof current==='number'&&current<=w.target&&fresh(w.coin);return '<article class="life-surface crypto-card"><div class="life-row-between"><h3>'+esc(C.coins[w.coin])+'</h3>'+btn('Изменить','crypto-watch',w.id)+'</div><strong>'+quoteText(w.coin)+'</strong><p class="life-small '+(hit?'crypto-positive':'life-muted')+'">'+(w.target?'Цель: '+amount(w.target,w.currency)+(hit?' · цена достигнута':''):'Цена входа не задана')+'</p><p class="crypto-text">'+esc(w.note)+'</p></article>';}).join('')+'</div>':empty('star','Твой список наблюдения','Добавь монеты и запиши, при какой цене хочешь вернуться к анализу.'));}
  function ideas(){return '<div class="life-actions">'+btn('Новая идея','crypto-idea')+'</div>'+(state().cryptoIdeas.length?'<div class="crypto-list">'+state().cryptoIdeas.map(i=>'<article class="life-surface crypto-card"><div class="life-row-between"><h3>'+esc(i.title)+'</h3>'+btn('Изменить','crypto-idea',i.id)+'</div><p class="life-small life-muted">'+esc(C.coins[i.coin])+' · '+({research:'Изучаю',watch:'Наблюдаю',closed:'Закрыта'})[i.stage]+'</p><p class="crypto-text">'+esc(i.thesis)+'</p><p class="crypto-text"><b>Риски:</b> '+esc(i.risks||'Не записаны')+'</p><p class="crypto-text"><b>Выход:</b> '+esc(i.exit||'Не определён')+'</p>'+(i.url?link(i.url,'Источник'):'')+'</article>').join('')+'</div>':empty('lightbulb','Идея до сделки','Запиши причины входа, риск и условия выхода.'));}
  function tasks(){const rows=state().tasks.filter(t=>t.cryptoCoin);return '<div class="life-actions">'+btn('Новая криптозадача','crypto-task')+'</div>'+(rows.length?'<section class="life-surface">'+rows.map(t=>o.taskRow(t).replace('data-task=', 'data-crypto-task=')).join('')+'</section>':empty('list-checks','Следующий шаг','Эти задачи также появятся в «Моём дне» на выбранную дату.'));}
  function research(){
    const candidates=Object.keys(C.coins).filter(id=>!['tether','usd-coin'].includes(id)&&quotes[id]?.usd_market_cap>1e9&&quotes[id]?.usd_24h_vol>5e7&&fresh(id)).sort((a,b)=>(quotes[b].usd_24h_vol/quotes[b].usd_market_cap)-(quotes[a].usd_24h_vol/quotes[a].usd_market_cap)).slice(0,5);
    return '<section class="life-surface"><h2>Монеты для изучения</h2><p class="life-small life-muted">Отбор среди 20 поддерживаемых монет: капитализация выше $1 млрд, объём торгов выше $50 млн за сутки. Сортировка по отношению объёма к капитализации. Это активность рынка, а не прогноз доходности.</p>'+(candidates.length?'<div class="crypto-list">'+candidates.map(id=>'<article class="crypto-card"><div class="life-row-between"><h3>'+esc(C.coins[id])+'</h3>'+btn('В избранное','crypto-watch-coin',id)+'</div><p>'+quoteText(id)+' · за 24 ч. '+pct(quotes[id].usd_24h_change??null)+'</p><p class="life-small life-muted">Объём: '+amount(quotes[id].usd_24h_vol,'USD')+' · капитализация: '+amount(quotes[id].usd_market_cap,'USD')+'</p>'+link('https://www.coingecko.com/en/coins/'+id,'Изучить данные')+'</article>').join('')+'</div>':'<p>Для отбора нужны свежие котировки с объёмами торгов.</p>')+'</section>';
  }
  function newsView(){return research()+'<section class="life-surface" style="margin-top:18px"><div class="life-row-between"><h2>Новости рынка</h2>'+btn(newsBusy?'Обновляю…':'Обновить новости','crypto-news-refresh')+'</div><p class="life-small life-muted">CoinDesk · заголовки на языке источника. Подписи ниже — автоматическая классификация темы, не оценка направления цены.'+(newsTime?' Лента получена '+time(newsTime)+'.':'')+'</p>'+(newsError?'<p class="app-error">'+esc(newsError)+'</p>':'')+(news.length?news.map(n=>'<article class="crypto-news"><p class="life-small life-muted">CoinDesk · '+time(n.date)+'</p><h3>'+esc(n.title)+'</h3><p>'+esc(C.newsReason(n.title))+'</p>'+link(n.url,'Читать источник')+'</article>').join(''):'<p>'+(newsBusy?'Загружаю новости…':'Новостей пока нет. Нажми «Обновить новости».')+'</p>')+'</section>';}
  function render(){
    setTimeout(()=>prices(),0);if(tab==='news')setTimeout(()=>loadNews(),0);
    const tabs={portfolio:'Портфель',operations:'Операции',watch:'Избранное',ideas:'Идеи',tasks:'Криптозадачи',news:'Новости и обзор'};
    return head('Крипта','Твой капитал, сделки и решения — в одном месте.',btn('＋ Операция','crypto-operation','',true))+'<div class="crypto-toolbar"><div class="crypto-tabs">'+Object.entries(tabs).map(([k,v])=>'<button class="life-button '+(tab===k?'life-button-primary':'')+'" data-action="crypto-tab" data-id="'+k+'" aria-pressed="'+(tab===k)+'">'+v+'</button>').join('')+'</div><div class="life-actions">'+btn(currency==='USD'?'$ USD ✓':'$ USD','crypto-currency','USD')+btn(currency==='RUB'?'₽ RUB ✓':'₽ RUB','crypto-currency','RUB')+btn(quoteBusy?'Обновляю…':'Обновить курсы','crypto-prices')+'</div></div><p class="life-small life-muted">Котировки CoinGecko · '+(quoteTime?'получены '+time(quoteTime):'ещё не загружены')+' · обновление раз в 5 минут, пока вкладка открыта. '+link('https://www.coingecko.com/','Источник')+'</p>'+(quoteError?'<p class="app-error">'+esc(quoteError)+' Показаны последние доступные значения.</p>':'')+({portfolio,operations,watch,ideas,tasks,news:newsView})[tab]();
  }
  async function action(name,id){if(!name.startsWith('crypto-'))return false;
    if(name==='crypto-tab'){tab=id;o.render();}
    if(name==='crypto-currency'){currency=id;o.render();}
    if(name==='crypto-operation')operationForm(id);
    if(name==='crypto-watch')watchForm(id);
    if(name==='crypto-watch-coin')watchForm(state().cryptoWatch.find(w=>w.coin===id)?.id||'',id);
    if(name==='crypto-idea')ideaForm(id);
    if(name==='crypto-task')taskForm();
    if(name==='crypto-prices')await prices(true);
    if(name==='crypto-news-refresh')await loadNews(true);
    return true;
  }
  setInterval(()=>{if(o.active()&&!document.hidden)prices();},300000);
  return {render,action,submit};
};
