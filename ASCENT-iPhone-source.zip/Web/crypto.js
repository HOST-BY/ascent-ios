(function(g){
  'use strict';
  const coins=Object.freeze({bitcoin:'BTC · Bitcoin',ethereum:'ETH · Ethereum',tether:'USDT · Tether','the-open-network':'GRAM · Gram (бывш. Toncoin / TON)',solana:'SOL · Solana','usd-coin':'USDC · USD Coin',binancecoin:'BNB · BNB',ripple:'XRP · XRP',dogecoin:'DOGE · Dogecoin',cardano:'ADA · Cardano',tron:'TRX · TRON',chainlink:'LINK · Chainlink',avalanche:'AVAX · Avalanche',polkadot:'DOT · Polkadot',litecoin:'LTC · Litecoin',sui:'SUI · Sui','near':'NEAR · NEAR',arbitrum:'ARB · Arbitrum',uniswap:'UNI · Uniswap',aave:'AAVE · Aave','adi-token':'ADI · ADI','pump-fun':'PUMP · Pump.fun','falcon-finance-ff':'FF · Falcon Finance',zcash:'ZEC · Zcash',ethena:'ENA · Ethena',pepe:'PEPE · Pepe'});
  const icons=Object.freeze({"bitcoin":"crypto-coin-bitcoin.png","ethereum":"crypto-coin-ethereum.png","tether":"crypto-coin-tether.png","binancecoin":"crypto-coin-binancecoin.png","ripple":"crypto-coin-ripple.png","usd-coin":"crypto-coin-usd-coin.png","solana":"crypto-coin-solana.png","tron":"crypto-coin-tron.png","zcash":"crypto-coin-zcash.png","dogecoin":"crypto-coin-dogecoin.png","chainlink":"crypto-coin-chainlink.png","cardano":"crypto-coin-cardano.png","uniswap":"crypto-coin-uniswap.png","near":"crypto-coin-near.jpg","litecoin":"crypto-coin-litecoin.png","avalanche":"crypto-coin-avalanche.png","sui":"crypto-coin-sui.png","the-open-network":"crypto-coin-the-open-network.png","aave":"crypto-coin-aave.png","ethena":"crypto-coin-ethena.png","pump-fun":"crypto-coin-pump-fun.jpg","pepe":"crypto-coin-pepe.jpg","polkadot":"crypto-coin-polkadot.jpg","arbitrum":"crypto-coin-arbitrum.jpg","falcon-finance-ff":"crypto-coin-falcon-finance-ff.png","adi-token":"crypto-coin-adi-token.png"});
  const types={buy:'Покупка',sell:'Продажа',opening:'Начальный остаток',transfer:'Перевод между своими кошельками'};
  const parse=(v,optional=false)=>{const s=String(v??'').trim().replace(/\s/g,'').replace(',','.');if(!s&&optional)return null;if(!s||!/^\d+(\.\d+)?$/.test(s))throw Error('Укажи неотрицательное число.');const n=Number(s);if(!Number.isFinite(n)||n>1e12)throw Error('Число слишком велико.');return n;};
  function validate(d){
    for(const k of ['cryptoOperations','cryptoWatch','cryptoIdeas']){
      if(d[k]===undefined)d[k]=[];
      if(!Array.isArray(d[k])||d[k].length>10000)throw Error('Некорректные криптозаписи.');
      const ids=new Set();for(const r of d[k]){if(!r||typeof r.id!=='string'||r.id.length>100||ids.has(r.id))throw Error('Некорректный идентификатор криптозаписи.');ids.add(r.id);}
    }
    const str=(v,n)=>typeof v==='string'&&v.length<=n;
    const num=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=1e12;
    const coin=v=>Object.hasOwn(coins,v);
    for(const o of d.cryptoOperations){
      if(!coin(o.coin)||!Object.hasOwn(types,o.type)||!num(o.quantity)||o.quantity<=0||!(o.price===null||num(o.price))||!['USD','RUB'].includes(o.currency)||!(o.fx===null||num(o.fx)&&o.fx>0)||!num(o.fee)||!['fiat','coin'].includes(o.feeCurrency)||!str(o.date,35)||!/^\d{4}-\d{2}-\d{2}T/.test(o.date)||!Number.isFinite(Date.parse(o.date))||!str(o.note,2000))throw Error('Некорректная криптооперация.');
      if(['buy','sell'].includes(o.type)&&!(o.price>0))throw Error('У покупки и продажи должна быть цена.');
      if(['buy','opening'].includes(o.type)&&o.feeCurrency==='coin'&&o.fee>=o.quantity)throw Error('Комиссия не может быть больше количества монет.');
      if(o.type==='sell'&&o.feeCurrency==='fiat'&&o.fee>o.quantity*o.price)throw Error('Комиссия больше суммы продажи.');
    }
    for(const w of d.cryptoWatch)if(!coin(w.coin)||!(w.target===null||num(w.target)&&w.target>0)||!['USD','RUB'].includes(w.currency)||!str(w.note,2000))throw Error('Некорректное избранное.');
    if(new Set(d.cryptoWatch.map(w=>w.coin)).size!==d.cryptoWatch.length)throw Error('Монета уже в избранном.');
    for(const i of d.cryptoIdeas)if(!coin(i.coin)||!str(i.title,180)||!str(i.thesis,5000)||!str(i.risks,5000)||!str(i.exit,2000)||!str(i.url,2000)||(i.url&&!/^https?:\/\//.test(i.url))||!['research','watch','closed'].includes(i.stage))throw Error('Некорректная криптоидея.');
    ledger(d.cryptoOperations);
    return d;
  }
  const add=(a,b)=>a===null||b===null?null:a+b;
  function amounts(amount,currency,fx){if(amount===0)return {USD:0,RUB:0};return {USD:currency==='USD'?amount:fx?amount/fx:null,RUB:currency==='RUB'?amount:fx?amount*fx:null};}
  function ledger(operations){
    const assets={},history={};
    const order={opening:0,buy:1,transfer:2,sell:3};
    for(const o of [...operations].sort((a,b)=>a.date.localeCompare(b.date)||order[a.type]-order[b.type]||a.id.localeCompare(b.id))){
      const a=assets[o.coin]??={coin:o.coin,quantity:0,cost:{USD:0,RUB:0},realized:{USD:0,RUB:0},soldCost:{USD:0,RUB:0}};
      const coinFee=o.feeCurrency==='coin'?o.fee:0,fiatFee=o.feeCurrency==='fiat'?o.fee:0;
      if(o.type==='buy'||o.type==='opening'){
        const paid=o.price===null?{USD:null,RUB:null}:amounts(o.quantity*o.price+fiatFee,o.currency,o.fx);
        a.quantity+=o.quantity-coinFee;for(const c of ['USD','RUB'])a.cost[c]=add(a.cost[c],paid[c]);
        history[o.id]={USD:null,RUB:null};continue;
      }
      if(o.type==='transfer'&&o.quantity>a.quantity+Math.max(1e-12,a.quantity*1e-10))throw Error('Для перевода '+coins[o.coin]+' недостаточно монет на эту дату.');
      const removed=o.type==='sell'?o.quantity+coinFee:coinFee;
      if(removed>a.quantity+Math.max(1e-12,a.quantity*1e-10))throw Error('Недостаточно '+coins[o.coin]+' на дату операции. Добавь более раннюю покупку или начальный остаток.');
      const fraction=a.quantity?Math.min(1,removed/a.quantity):0,proceeds=amounts(o.type==='sell'?o.quantity*o.price-fiatFee:-fiatFee,o.currency,o.fx);
      history[o.id]={};
      for(const c of ['USD','RUB']){
        const cost=removed===0?0:a.cost[c]===null?null:a.cost[c]*fraction;
        const pnl=cost===null||proceeds[c]===null?null:proceeds[c]-cost;
        history[o.id][c]=pnl;a.realized[c]=add(a.realized[c],pnl);a.soldCost[c]=add(a.soldCost[c],cost);
        if(a.cost[c]!==null)a.cost[c]-=cost;
      }
      a.quantity=Math.max(0,a.quantity-removed);if(a.quantity<1e-12){a.quantity=0;a.cost={USD:0,RUB:0};}
    }
    return {assets:Object.values(assets),history};
  }
  function portfolio(operations,quotes){
    const l=ledger(operations),total={USD:{value:0,cost:0,unrealized:0,realized:0},RUB:{value:0,cost:0,unrealized:0,realized:0}};
    const assets=l.assets.map(a=>{const out={...a,values:{}};for(const c of ['USD','RUB']){
      const q=quotes[a.coin]?.[c.toLowerCase()],price=typeof q==='number'&&Number.isFinite(q)&&q>0?q:null;
      const value=a.quantity===0?0:price===null?null:a.quantity*price,cost=a.cost[c],pnl=value===null||cost===null?null:value-cost;
      out.values[c]={price,value,cost,average:cost===null||!a.quantity?null:cost/a.quantity,pnl,percent:pnl===null||!cost?null:pnl/cost*100};
      for(const [key,val] of Object.entries({value,cost,unrealized:pnl,realized:a.realized[c]}))total[c][key]=add(total[c][key],val);
    }return out;});return {assets,total,history:l.history};
  }
  function newsReason(title){
    if(/hack|exploit|breach|attack/i.test(title))return 'Безопасность: проверь масштаб инцидента и затронутые проекты.';
    if(/sec|regulat|ban|law|court|lawsuit/i.test(title))return 'Регулирование: решение может повлиять на доступ к рынку и ликвидность.';
    if(/etf|inflow|outflow|fund/i.test(title))return 'Потоки капитала: проверь фактические объёмы и период, а не только заголовок.';
    if(/rate|fed|inflation|oil|war/i.test(title))return 'Макроэкономика: изменение спроса на риск может затронуть весь рынок.';
    if(/unlock|listing|launch|upgrade/i.test(title))return 'Событие проекта: проверь дату, изменение предложения и официальное подтверждение.';
    return 'Рыночный контекст: изучи первоисточник и проверь, относится ли событие к твоим монетам.';
  }
  const api={coins,icons,types,parse,validate,ledger,portfolio,newsReason};g.AscentCrypto=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
