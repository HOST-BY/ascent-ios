/* Account tokens stay in native protected storage; backups contain records only. */
(() => {
  'use strict';
  const copy = x => JSON.parse(JSON.stringify(x));
  const stable = x => JSON.stringify(x, (_, v) => v && !Array.isArray(v) && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map(k => [k,v[k]])) : v);
  function documentOf(s) { const d=copy(s); delete d.updatedAt; delete d.timer; delete d.notified; return d; }
  // Row-level three-way merge. Deletions propagate; concurrent edits to the same row stop the sync.
  function merge(base, local, remote) {
    const conflicts=[];
    function value(b,l,r,path) {
      if(stable(l)===stable(r))return l;
      if(stable(l)===stable(b))return r;
      if(stable(r)===stable(b))return l;
      conflicts.push(path); return l;
    }
    const result={};
    for(const k of new Set([...Object.keys(base),...Object.keys(local),...Object.keys(remote)])) {
      const b=base[k],l=local[k],r=remote[k];
      if(Array.isArray(b)&&Array.isArray(l)&&Array.isArray(r)&&[...b,...l,...r].every(x=>x&&typeof x.id==='string')) {
        const bm=new Map(b.map(x=>[x.id,x])),lm=new Map(l.map(x=>[x.id,x])),rm=new Map(r.map(x=>[x.id,x]));
        result[k]=[...new Set([...rm.keys(),...lm.keys(),...bm.keys()])].map(id=>value(bm.get(id),lm.get(id),rm.get(id),k+'/'+id)).filter(x=>x!==undefined);
      } else if(k==='settings' && b && l && r) {
        result[k]={}; for(const p of new Set([...Object.keys(b),...Object.keys(l),...Object.keys(r)]))result[k][p]=value(b[p],l[p],r[p],'settings/'+p);
      } else result[k]=value(b,l,r,k);
    }
    return {document:result,conflicts};
  }
  class Client {
    constructor(o){this.o=o;this.session=null;this.meta={};this.message='Вход не выполнен';this.busy=false;this.pending=null;this.timer=null;}
    status(message){this.message=message;this.o.status();}
    async init(){const saved=await this.o.rpc('cloudRead');this.session=saved.session?JSON.parse(saved.session):null;this.meta=saved.meta?JSON.parse(saved.meta):{};this.status(this.session?'Подключение к облаку…':'Вход не выполнен');if(this.session)this.schedule(1000);this.interval=setInterval(()=>this.schedule(0),30000);}
    async request(path,body,auth=true,method=body===undefined?'GET':'POST'){
      const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),25000);
      try {
        const headers={apikey:this.o.config.key,'Content-Type':'application/json'};
        if(auth)headers.Authorization='Bearer '+this.session.access_token;
        const response=await fetch(this.o.config.url+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:controller.signal});
        const data=await response.json().catch(()=>null);
        if(!response.ok){const error=new Error(data?.message||data?.msg||data?.error_description||'Облако недоступно ('+response.status+')');error.status=response.status;error.code=data?.code;throw error;}
        return data;
      } finally {clearTimeout(timeout);}
    }
    async saveSession(session){await this.o.rpc('cloudSession',{json:session?JSON.stringify(session):''});this.session=session;}
    async login(email,password){
      if(this.busy)throw new Error('Дождись завершения синхронизации.');
      this.busy=true;
      try {const s=await this.request('/auth/v1/token?grant_type=password',{email,password},false);s.expires_at=Date.now()/1000+s.expires_in;
        if(this.meta.owner && this.meta.owner!==s.user.id)throw new Error('На этом устройстве уже подключён другой аккаунт ASCENT. Сначала экспортируй данные; автоматическое смешивание аккаунтов отключено.');
        if(!this.meta.owner)await this.saveMeta({owner:s.user.id});
        await this.saveSession(s);this.status('Вход выполнен');
      }finally{this.busy=false;}this.schedule(0);
    }
    async signup(email,password){await this.request('/auth/v1/signup',{email,password},false);return 'Проверь почту и подтверди адрес, затем нажми «Войти».';}
    async logout(){if(this.busy)throw new Error('Дождись завершения синхронизации.');await this.saveSession(null);this.pending=null;clearTimeout(this.timer);this.status('Синхронизация отключена. Данные остались на устройстве.');}
    async refresh(){if(this.session.expires_at>Date.now()/1000+90)return;const s=await this.request('/auth/v1/token?grant_type=refresh_token',{refresh_token:this.session.refresh_token},false);s.expires_at=Date.now()/1000+s.expires_in;await this.saveSession(s);}
    schedule(delay=1500){if(!this.session||this.pending)return;clearTimeout(this.timer);this.timer=setTimeout(()=>this.sync(),delay);}
    async saveMeta(meta){await this.o.rpc('cloudMeta',{json:JSON.stringify(meta)});this.meta=meta;}
    async sync(choice){
      if(this.busy||!this.session||this.pending&&!choice)return;
      this.busy=true;this.status('Синхронизация…');
      try {
        await this.refresh();await this.o.flush();
        const filter='&user_id=eq.'+encodeURIComponent(this.session.user.id);
        const versions=await this.request('/rest/v1/ascent_documents?select=revision'+filter);
        const rows=versions[0] && this.meta.base && versions[0].revision===this.meta.revision
          ? [{revision:versions[0].revision,document:this.meta.base}]
          : versions[0] ? await this.request('/rest/v1/ascent_documents?select=revision,document'+filter) : [];
        const remote=rows[0],local=documentOf(this.o.get()),base=this.meta.base;
        if(remote)this.o.validate(copy(remote.document));
        let next=local;
        if(choice){
          // A choice is valid only for the exact remote version shown to the user.
          if(remote?.revision!==this.pending?.revision){this.pending=null;throw new Error('Облачная версия изменилась. Повтори синхронизацию.');}
          await this.o.rpc('cloudBackup',{json:JSON.stringify({local:this.o.get(),remote:remote.document})});
          next=choice==='remote'?remote.document:local;
        } else if(remote && !base){
          if(stable(local)!==stable(remote.document)){this.pending={revision:remote.revision,first:true};this.status('Выбери данные для первого подключения');return;}
        } else if(remote && base){
          const merged=merge(base,local,remote.document);
          if(merged.conflicts.length){await this.o.rpc('cloudBackup',{json:JSON.stringify({local:this.o.get(),remote:remote.document})});this.pending={revision:remote.revision,conflicts:merged.conflicts};this.status('Изменения на двух устройствах — нужен выбор');return;}
          next=merged.document;
        } else if(!remote && base){throw new Error('Облачные данные отсутствуют. Автоматическая запись приостановлена.');}
        this.o.validate(copy(next));
        let rev=remote?.revision||0;
        if(!remote||stable(next)!==stable(remote.document)){
          if(new TextEncoder().encode(JSON.stringify(next)).length>45*1024*1024)throw new Error('Для этой версии синхронизации лимит копии — 45 МБ. Локальные данные сохранены.');
          rev=await this.request('/rest/v1/rpc/ascent_save',{expected_revision:rev,new_document:next});
        }
        // Edits made while the request was in flight are retained and merged on the next cycle.
        const current=documentOf(this.o.get());
        const after=merge(local,current,next);
        if(after.conflicts.length){this.pending={revision:rev,conflicts:after.conflicts};this.status('Новые изменения — нужен выбор');return;}
        if(stable(after.document)!==stable(current))await this.o.apply(copy(after.document));
        await this.saveMeta({owner:this.session.user.id,base:copy(next),revision:rev});
        this.pending=null;this.status('Синхронизировано · '+new Date().toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}));
        if(stable(documentOf(this.o.get()))!==stable(next))this.schedule(1500);
      }catch(e){this.status(e.status===401||e.status===400&&e.code?.includes('refresh')?'Войди в аккаунт повторно':e.code==='40001'?'Облако обновилось — повторяем синхронизацию':e.name==='AbortError'?'Нет ответа от облака. Повторим автоматически.':e.message);}
      finally{this.busy=false;this.o.status();}
    }
  }
  const api={Client,merge,documentOf,stable};if(typeof module!=='undefined')module.exports=api;else window.AscentCloud=api;
})();
