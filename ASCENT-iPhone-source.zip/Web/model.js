(function(global){
  'use strict';
  const day = (date=new Date()) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
  const id = () => global.crypto.randomUUID();
  const navPages=Object.freeze(['goals','day','habits','finance','body','creative','notes','ai','settings']);
  const priorityColors = Object.freeze({high:'#ff7676',medium:'#f4cc62',normal:'#76d39b'});
  const addDays = (date,n) => { const d=new Date(date+'T12:00:00'); d.setDate(d.getDate()+n); return day(d); };
  const parseAmount = value => { const n=Number(String(value).replace(/\s/g,'').replace(',','.')); if(!Number.isFinite(n)||n<0||n>1e12) throw new Error('Проверь сумму: нужно число от 0 до 1 трлн.'); return Math.round(n*100)/100; };
  function initial(){return {
    app:'ASCENT',version:1,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),
    settings:{descriptionColor:'#b9bed1',descriptionsOpen:true,descriptionExceptions:[],navOrder:[...navPages],why:'Больше свободы. Своя квартира и машина. Время на то, что действительно важно.',accent:'violet',priorityColors:{...priorityColors},model:'gpt-5-mini',focusMinutes:25,reminders:true,monthlyBudgets:{},categoryBudgets:{}},
    goals:[
      {id:'income',title:'Доход 300 000 ₽ / месяц',why:'Больше свободы в решениях и уверенности в будущем.',domain:'finance',icon:'trending-up',kind:'income',target:300000,current:0,unit:'₽ / месяц',deadline:'',steps:[{id:id(),title:'Разобрать текущие источники дохода',done:false},{id:id(),title:'Выбрать направление роста дохода',done:false}]},
      {id:'youtube',title:'Развивать YouTube',why:'Создавать своё и находить людей, которым это интересно.',domain:'development',icon:'clapperboard',kind:'number',target:0,current:0,unit:'подписчиков',deadline:'',steps:[{id:id(),title:'Определить тему канала',done:false},{id:id(),title:'Подготовить первый ролик',done:false},{id:id(),title:'Опубликовать и разобрать результат',done:false}]},
      {id:'license',title:'Сдать на права',why:'Свобода передвижения и самостоятельность.',domain:'development',icon:'car-front',kind:'steps',target:0,current:0,unit:'этапов',deadline:'',steps:[{id:id(),title:'Выбрать автошколу',done:false},{id:id(),title:'Пройти теорию и практику',done:false},{id:id(),title:'Сдать экзамены',done:false}]},
      {id:'home',title:'Купить квартиру',why:'Своё пространство, в котором хорошо.',domain:'finance',icon:'house',kind:'number',target:0,current:0,unit:'₽ накоплено',deadline:'',steps:[{id:id(),title:'Определить требования и бюджет',done:false},{id:id(),title:'Составить план накоплений',done:false}]},
      {id:'car',title:'Купить машину',why:'Комфорт и больше возможностей.',domain:'finance',icon:'key-round',kind:'number',target:0,current:0,unit:'₽ накоплено',deadline:'',steps:[{id:id(),title:'Выбрать ориентир по стоимости',done:false},{id:id(),title:'Составить план накоплений',done:false}]}
    ],creativeIdeas:[],creativeProjects:[],tasks:[],notes:[],transactions:[],workouts:[],measurements:[],meals:[],chats:[],
    habits:[{id:id(),title:'Утренний вакуум',domain:'body',dates:[]},{id:id(),title:'Записать питание',domain:'body',dates:[]}],
    categories:[{id:'food',name:'Еда',icon:'shopping-basket',type:'expense'},{id:'transport',name:'Транспорт',icon:'bus',type:'expense'},{id:'home',name:'Дом',icon:'house',type:'expense'},{id:'subscriptions',name:'Подписки',icon:'monitor-play',type:'expense'},{id:'health',name:'Здоровье',icon:'heart-pulse',type:'expense'},{id:'fun',name:'Отдых',icon:'coffee',type:'expense'},{id:'work',name:'Работа',icon:'briefcase-business',type:'income'},{id:'extra',name:'Подработка',icon:'laptop',type:'income'},{id:'other-expense',name:'Другое',icon:'wallet',type:'expense'},{id:'other-income',name:'Другое',icon:'wallet',type:'income'}],
    templates:[{id:id(),title:'Вечерний разбор дня',tasks:['Разобрать входящие заметки','Записать расходы','Выбрать главное дело на завтра']},{id:id(),title:'Подготовка ролика',tasks:['Определить тему ролика','Набросать сценарий','Подготовить съёмку']}],
    timer:{running:false,endAt:0,remaining:1500},notified:[]
  };}
  const isDate = value => typeof value==='string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(new Date(value+'T12:00:00').getTime()) && day(new Date(value+'T12:00:00'))===value;
  function validate(d){
    const fail=()=>{throw new Error('Файл содержит повреждённые или несовместимые данные ASCENT.');};
    if(!d||d.app!=='ASCENT'||d.version!==1||!d.settings||Array.isArray(d.settings))fail();
    if(d.creativeIdeas===undefined)d.creativeIdeas=[];
    if(d.creativeProjects===undefined)d.creativeProjects=[];
    const arrays=['creativeIdeas','creativeProjects','goals','tasks','notes','transactions','workouts','measurements','meals','habits','categories','templates','chats'];
    arrays.forEach(k=>{if(!Array.isArray(d[k])||d[k].length>100000)fail();const ids=new Set();d[k].forEach(r=>{if(!r||typeof r!=='object'||typeof r.id!=='string'||r.id.length>100||ids.has(r.id))fail();ids.add(r.id);});});
    const text=(v,n=20000)=>typeof v==='string'&&v.length<=n;
    const num=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=1e12;
    const dates=v=>Array.isArray(v)&&v.every(isDate);
    const images=v=>Array.isArray(v)&&v.length<=12&&v.every(s=>typeof s==='string'&&s.length<=12*1024*1024&&/^data:image\/(jpeg|png|webp);base64,[a-zA-Z0-9+/=]+$/.test(s));
    const audio=v=>v===null||(v&&text(v.name,255)&&text(v.data,15000000)&&/^data:audio\/(mpeg|wav|x-wav|ogg|mp4|webm);base64,[a-zA-Z0-9+/=]+$/.test(v.data));
    const creative=r=>text(r.title,180)&&text(r.text,100000)&&text(r.category,60)&&images(r.images)&&audio(r.audio);
    d.creativeIdeas.forEach(r=>{if(!creative(r)||!num(r.x)||!num(r.y)||r.x>1400||r.y>3000||!text(r.projectId,100))fail();});
    d.creativeProjects.forEach(r=>{if(!creative(r)||!['idea','try','work','done'].includes(r.stage)||!text(r.why)||!text(r.firstStep,400)||!text(r.firstTaskId,100)||!text(r.result,2000)||(r.result&&!/^https?:\/\//i.test(r.result))||!Array.isArray(r.steps)||r.steps.length>100||r.steps.some(t=>!text(t.id,100)||!text(t.title,400)||!text(t.taskId,100)))fail();});
    d.goals.forEach(g=>{if(!text(g.title,180)||!text(g.why)||!['finance','body','development'].includes(g.domain)||!['steps','number','income'].includes(g.kind)||!num(g.target)||!num(g.current)||!text(g.unit,80)||!Array.isArray(g.steps)||g.steps.some(s=>!text(s.id,100)||!text(s.title,400)||typeof s.done!=='boolean')||(g.deadline&&!isDate(g.deadline)))fail();});
    d.tasks.forEach(t=>{if(t.urgent===undefined)t.urgent=false;if(typeof t.urgent!=='boolean'||!text(t.title,400)||!text(t.description)||!['none','daily','weekdays','weekly','monthly'].includes(t.repeat)||!['normal','medium','high'].includes(t.priority)||(t.date&&!isDate(t.date))||!dates(t.completedDates)||!dates(t.skipDates)||(t.completedOn&&!isDate(t.completedOn))||(t.reminder&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(t.reminder)))fail();});
    d.transactions.forEach(t=>{if(!num(t.amount)||!isDate(t.date)||!['expense','income'].includes(t.type)||!text(t.description,1000)||!text(t.categoryId,100))fail();});
    d.notes.forEach(n=>{if(!text(n.title,180)||!text(n.text,100000)||!text(n.tag,60)||!images(n.images))fail();});
    d.habits.forEach(h=>{if(!text(h.title,180)||!dates(h.dates)||!['finance','body','development'].includes(h.domain))fail();});
    d.meals.forEach(m=>{if(!isDate(m.date)||!text(m.title,180)||!text(m.text,10000))fail();});
    d.measurements.forEach(m=>{if(!isDate(m.date)||!images(m.images)||['weight','fat','waist','chest','hips','arm'].some(k=>m[k]!==null&&!num(m[k])))fail();});
    d.workouts.forEach(w=>{if(!isDate(w.date)||!text(w.title,180)||!text(w.notes,20000)||!num(w.minutes)||!Array.isArray(w.exercises)||w.exercises.some(e=>!text(e.name,180)||!num(e.sets)||!num(e.reps)||!num(e.weight)))fail();});
    d.categories.forEach(c=>{if(!text(c.name,100)||!text(c.icon,80)||!['expense','income'].includes(c.type))fail();});
    d.templates.forEach(t=>{if(!text(t.title,180)||!Array.isArray(t.tasks)||t.tasks.some(s=>!text(s,400)))fail();});
    d.chats.forEach(c=>{if(!text(c.question,20000)||!text(c.answer,100000))fail();});
    if(!text(d.settings.why)||!['violet','blue','orange'].includes(d.settings.accent)||!text(d.settings.model,100)||!num(d.settings.focusMinutes)||d.settings.focusMinutes<1||d.settings.focusMinutes>180)fail();
    if(d.settings.descriptionColor===undefined)d.settings.descriptionColor='#b9bed1';
    if(typeof d.settings.descriptionColor!=='string'||!/^#[0-9a-f]{6}$/i.test(d.settings.descriptionColor))fail();
    if(d.settings.descriptionsOpen===undefined)d.settings.descriptionsOpen=true;
    if(d.settings.descriptionExceptions===undefined)d.settings.descriptionExceptions=[];
    if(typeof d.settings.descriptionsOpen!=='boolean'||!Array.isArray(d.settings.descriptionExceptions)||d.settings.descriptionExceptions.some(id=>!text(id,100)))fail();
    d.settings.descriptionExceptions=[...new Set(d.settings.descriptionExceptions)].filter(id=>d.tasks.some(t=>t.id===id));
    if(d.settings.navOrder===undefined)d.settings.navOrder=[...navPages];
    if(!Array.isArray(d.settings.navOrder)||d.settings.navOrder.some(k=>typeof k!=='string'))fail();
    d.settings.navOrder=[...new Set(d.settings.navOrder.filter(k=>navPages.includes(k))),...navPages.filter(k=>!d.settings.navOrder.includes(k))];
    if(d.settings.priorityColors===undefined)d.settings.priorityColors={...priorityColors};
    if(!d.settings.priorityColors||Array.isArray(d.settings.priorityColors)||typeof d.settings.priorityColors!=='object')fail();
    Object.entries(priorityColors).forEach(([key,fallback])=>{if(d.settings.priorityColors[key]===undefined)d.settings.priorityColors[key]=fallback;if(typeof d.settings.priorityColors[key]!=='string'||!/^#[0-9a-f]{6}$/i.test(d.settings.priorityColors[key]))fail();});
    ['monthlyBudgets','categoryBudgets'].forEach(k=>{const o=d.settings[k];if(!o||typeof o!=='object'||Array.isArray(o)||Object.values(o).some(v=>!num(v)))fail();});
    if(!d.timer||typeof d.timer.running!=='boolean'||!num(d.timer.remaining)||typeof d.timer.endAt!=='number'||!Number.isFinite(d.timer.endAt)||d.timer.endAt<0)d.timer={running:false,endAt:0,remaining:1500};
    if(!Array.isArray(d.notified))d.notified=[];
    return d;
  }
  function dueAt(t,date){
    if(!t.date||t.date>date||(t.skipDates||[]).includes(date))return false;
    const anchor=new Date(t.date+'T12:00:00'),now=new Date(date+'T12:00:00');
    if(t.repeat==='none')return t.date===date;
    if(t.repeat==='daily')return true;
    if(t.repeat==='weekdays')return now.getDay()!==0&&now.getDay()!==6;
    if(t.repeat==='weekly')return anchor.getDay()===now.getDay();
    if(t.repeat==='monthly'){const last=new Date(now.getFullYear(),now.getMonth()+1,0).getDate();return now.getDate()===Math.min(anchor.getDate(),last);}
    return false;
  }
  const doneAt=(t,date)=>t.repeat==='none'?Boolean(t.completedOn):t.completedDates.includes(date);
  function toggleTask(t,date){if(t.repeat==='none')t.completedOn=t.completedOn?'':date;else{const i=t.completedDates.indexOf(date);if(i>=0)t.completedDates.splice(i,1);else t.completedDates.push(date);}}
  const makeTask=(title,date=day(),extra={})=>Object.assign({id:id(),title,description:'',date,repeat:'none',priority:'normal',urgent:false,goalId:'',reminder:'',completedOn:'',completedDates:[],skipDates:[]},extra);
  function setTaskPriority(d,taskId,priority){if(!Object.hasOwn(priorityColors,priority))throw new Error('Неизвестный приоритет.');const t=d.tasks.find(t=>t.id===taskId);if(!t)throw new Error('Задача не найдена.');t.priority=priority;}
  function moveTask(d,taskId,from,to){const t=d.tasks.find(t=>t.id===taskId);if(!t)throw new Error('Задача не найдена.');if(t.repeat==='none'){t.date=to;}else{if(!t.skipDates.includes(from))t.skipDates.push(from);d.tasks.push(makeTask(t.title,to,{description:t.description,priority:t.priority,urgent:!!t.urgent,goalId:t.goalId,reminder:t.reminder}));}}
  const sum=(items)=>items.reduce((c,t)=>c+Math.round(t.amount*100),0)/100;
  function finance(d,month){const rows=d.transactions.filter(t=>t.date.startsWith(month)),income=sum(rows.filter(t=>t.type==='income')),expense=sum(rows.filter(t=>t.type==='expense')),limit=d.settings.monthlyBudgets[month]||0;return {rows,income,expense,limit,remaining:limit-expense,net:Math.round((income-expense)*100)/100};}
  function goalProgress(d,g,date=day()){if(g.kind==='income'){const current=finance(d,date.slice(0,7)).income;return {current,target:g.target,percent:g.target?Math.min(100,current/g.target*100):0};}if(g.kind==='number')return {current:g.current,target:g.target,percent:g.target?Math.min(100,g.current/g.target*100):0};const current=g.steps.filter(s=>s.done).length,target=g.steps.length;return {current,target,percent:target?current/target*100:0};}
  function xp(d){const result={finance:d.transactions.length*5,body:d.workouts.length*30+d.meals.length*5,development:0};d.tasks.forEach(t=>{const g=d.goals.find(g=>g.id===t.goalId),domain=g?g.domain:'development';result[domain]+=(t.repeat==='none'?(t.completedOn?1:0):t.completedDates.length)*20;});d.habits.forEach(h=>result[h.domain]+=new Set(h.dates).size*5);d.goals.forEach(g=>result[g.domain]+=g.steps.filter(s=>s.done).length*10);result.total=result.finance+result.body+result.development;return result;}
  function parseCsv(text){
    text=text.replace(/^\uFEFF/,'');
    const first=text.split(/\r?\n/)[0],separator=first.includes(';')?';':',';
    const rows=[];let row=[],cell='',quoted=false;
    for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}else if(c===separator&&!quoted){row.push(cell);cell='';}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(x=>x.trim()))rows.push(row);row=[];cell='';}else cell+=c;}
    if(quoted)throw new Error('В CSV не закрыты кавычки.');row.push(cell);if(row.some(x=>x.trim()))rows.push(row);
    if(rows.length<2)throw new Error('В CSV нет операций.');
    const header=rows.shift().map(x=>x.trim().toLowerCase()),expected=['date','type','category','amount','description'];
    if(expected.some(k=>!header.includes(k)))throw new Error('Нужны колонки: date;type;category;amount;description. Скачай шаблон в разделе импорта.');
    if(rows.length>10000)throw new Error('За один раз можно импортировать до 10 000 операций.');
    return rows.map((r,i)=>{const v=k=>String(r[header.indexOf(k)]||'').trim();const date=v('date'),type=v('type');if(!isDate(date)||!['expense','income'].includes(type))throw new Error('Строка '+(i+2)+': дата YYYY-MM-DD, тип expense или income.');const amount=parseAmount(v('amount'));if(amount<=0)throw new Error('Строка '+(i+2)+': сумма должна быть больше нуля.');return {date,type,amount,category:v('category')||'Другое',description:v('description')};});
  }
  function importTransactions(d,rows){let added=0,skipped=0;rows.forEach(row=>{let c=d.categories.find(c=>c.type===row.type&&c.name.toLowerCase()===row.category.toLowerCase());if(!c){c={id:id(),name:row.category,icon:'wallet',type:row.type};d.categories.push(c);}if(d.transactions.some(t=>t.date===row.date&&t.type===row.type&&t.amount===row.amount&&t.categoryId===c.id&&t.description===row.description)){skipped++;return;}d.transactions.push({id:id(),date:row.date,type:row.type,categoryId:c.id,amount:row.amount,description:row.description});added++;});return {added,skipped};}
  const api={id,day,addDays,parseAmount,priorityColors,initial,validate,isDate,dueAt,doneAt,toggleTask,makeTask,setTaskPriority,moveTask,finance,goalProgress,xp,parseCsv,importTransactions,sum};
  global.AscentModel=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
