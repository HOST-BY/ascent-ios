window.AscentCloudConfig = Object.freeze({
  url: 'https://vrxlewugzmqywuliwlef.supabase.co',
  key: 'sb_publishable_MFsr1IhN9UcQkyTT6uBGiA_0l3wzb2S'
});
