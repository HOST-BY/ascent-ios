import Foundation

enum AscentError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(text) = self { return text }; return nil }
}

final class AscentStore {
    let directory: URL
    let fileManager = FileManager.default
    var dataURL: URL { directory.appendingPathComponent("data.json") }
    var previousURL: URL { directory.appendingPathComponent("data.previous.json") }

    init(directory: URL? = nil) throws {
        self.directory = try directory ?? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("ASCENT", isDirectory: true)
        try fileManager.createDirectory(at: self.directory, withIntermediateDirectories: true)
        try fileManager.createDirectory(at: self.directory.appendingPathComponent("backups"), withIntermediateDirectories: true)
    }
    func validate(_ data: Data) throws {
        guard data.count <= 100 * 1024 * 1024,
              let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              root["app"] as? String == "ASCENT", root["version"] as? Int == 1,
              root["settings"] is [String: Any] else { throw AscentError.message("Неподдерживаемая или повреждённая копия ASCENT.") }
        for name in ["goals", "tasks", "notes", "transactions", "workouts", "measurements", "meals", "habits", "categories", "templates", "chats"] {
            guard root[name] is [Any] else { throw AscentError.message("Некорректный раздел: \(name).") }
        }
    }
    func read(_ url: URL) throws -> Data {
        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size <= 100 * 1024 * 1024 else { throw AscentError.message("Файл больше 100 МБ.") }
        let data = try Data(contentsOf: url)
        try validate(data)
        return data
    }
    func load() throws -> [String: Any] {
        if !fileManager.fileExists(atPath: dataURL.path) { return ["json": NSNull(), "recovered": false] }
        do { return ["json": String(decoding: try read(dataURL), as: UTF8.self), "recovered": false] }
        catch {
            let previous = try read(previousURL)
            let damaged = directory.appendingPathComponent("data.damaged-\(UUID().uuidString).json")
            try fileManager.copyItem(at: dataURL, to: damaged)
            try previous.write(to: dataURL, options: .atomic)
            return ["json": String(decoding: previous, as: UTF8.self), "recovered": true]
        }
    }
    func save(_ json: String) throws {
        let data = Data(json.utf8)
        try validate(data)
        if fileManager.fileExists(atPath: dataURL.path) {
            let old = try read(dataURL)
            try old.write(to: previousURL, options: .atomic)
            let date = DateFormatter(); date.locale = Locale(identifier: "en_US_POSIX"); date.dateFormat = "yyyy-MM-dd"
            let backup = directory.appendingPathComponent("backups/\(date.string(from: Date())).json")
            if !fileManager.fileExists(atPath: backup.path) { try old.write(to: backup, options: .atomic) }
        }
        try data.write(to: dataURL, options: .atomic)
    }
}
