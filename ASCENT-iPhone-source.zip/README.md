# ASCENT 0.8 for iPhone

Native iOS shell for a personal planner, habits, finances, notes and creative projects. Install with AltStore Classic.

Source code is in ASCENT-iPhone-source.zip. The root GitHub Actions workflow extracts it, tests file storage and builds an unsigned arm64 IPA. Run Actions → Build ASCENT for AltStore → Run workflow, then download ASCENT-iPhone-AltStore.

Version 0.8 adds a shared ASCENT account for Windows and iPhone using Supabase Auth and private snapshots. Client connection settings contain only a public publishable key. Account sessions are stored using Windows DPAPI or iOS Keychain; no credentials or personal records are included in the source.

Sync runs after edits, every 30 seconds while open, and when returning to the app. Independent row changes merge; concurrent edits to the same row require a choice and preserve a local conflict backup. First connection to existing cloud data requires an explicit choice. The current snapshot size limit is 45 MiB, including photos and audio. Timers and notification history remain device-local. Offline edits stay on the device.

Backend schema is in cloud/schema.sql inside the archive. An administrator creates the personal account in Supabase Authentication; email delivery is not configured. Both devices use the same account. Supabase dashboard login is separate.

Automated model, file-storage, merge and mock two-device tests do not replace testing sign-in and installation on the actual iPhone. No background iOS sync or background notifications are promised. Keep a JSON backup before updating or connecting an account.

## 0.9: Crypto
Manual portfolio and operations, quotes in RUB/USD, average-cost P&L with fees, watchlist, research ideas, tasks and source-linked news. Supports 26 assets; no wallet import. No account credentials or personal records in this archive.

Version 0.9.1 adds ADI, PUMP, FF, ZEC, ENA, PEPE and bundled offline coin logos. Toncoin is displayed as GRAM while retaining its existing record identity. Avalanche quote mapping corrected. No screenshot balances or transactions are imported.
